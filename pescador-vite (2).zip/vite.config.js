import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' mantém caminhos relativos (GitHub Pages, Vercel e Cloudflare).
export default defineConfig({
  base: './',
  plugins: [react()],
  build: { outDir: 'dist', emptyOutDir: true },
});
